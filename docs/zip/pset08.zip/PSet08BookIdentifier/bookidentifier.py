"""
|-------------------------------------------------------------------------------
| bookidentifier.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 28, 2019
|
| This program checks the validity of ISBN codes.
|
"""

def validatebook(isbncode):
    # YOUR CODE HERE
    

result = validatebook("0789751984")
print(result)

