"""
|-------------------------------------------------------------------------------
| notefrequency.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 15, 2019
|
| This program determines the frequency(in Hz) for a particular octave and
| pitch class.
|
"""

def temperedscale(octave, pitch):
    # YOUR CODE HERE
    
    return frequency

result = temperedscale(0, 0)
print(result)
