"""
|-------------------------------------------------------------------------------
| waterbilling.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 08, 2019
|
| This program determines the amount of a customer's water bill.
|
"""

def calculatebill(customer, begin, end):
    # YOUR CODE HERE
    

result = calculatebill("residential", 444400003, 444400135)
print(result)

