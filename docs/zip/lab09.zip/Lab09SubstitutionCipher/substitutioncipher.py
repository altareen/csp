"""
|-------------------------------------------------------------------------------
| substitutioncipher.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 21, 2019
|
| This program encrypts a message using the substitution cipher.
|
"""

def encrypt(message, key):
    alpha = "abcdefghijklmnopqrstuvwxyz"
    # YOUR CODE HERE
    

result = encrypt("hello", "jtrekyavogdxpsncuizlfbmwhq")
print(result)

