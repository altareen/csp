"""
|-------------------------------------------------------------------------------
| vendingmachine.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 13, 2019
|
| This program simulates a simple change maker for a vending machine.
|
"""

def dispensechange(quarters, dimes, nickels, cost, payment):
    # YOUR CODE HERE
    

result = dispensechange(5, 5, 5, 160, 200)
print(result)

