"""
|-------------------------------------------------------------------------------
| downpayment.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 18, 2019
|
| This program determines the number of months required for a down payment.
|
"""

def savingsduration(annualsalary, percentsaved, totalcost, payraise):
    # YOUR CODE HERE
    

result = savingsduration(120000, 0.05, 500000, 0.03)
print(result)

