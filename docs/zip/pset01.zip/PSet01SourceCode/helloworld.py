"""
|-------------------------------------------------------------------------------
| helloworld
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: May 20, 2019
|
| This program displays a simple greeting to the user.
|
"""

def displaymessage():
    # Use the assignment operator to assign the message [hello world]
    # to the string variable [greetings].
    # YOUR CODE HERE
    
    return greetings

print(displaymessage())

