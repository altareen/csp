"""
|-------------------------------------------------------------------------------
| smoothsignal.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 30, 2019
|
| This program smoothes an audio signal by averaging intensities.
|
"""

def levelling(audio):
    # YOUR CODE HERE
    

signal = [1, 5, 4, 5, 7, 6, 8, 6, 5, 4, 5, 4]
result = levelling(signal)
print(result)

