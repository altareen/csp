"""
|-------------------------------------------------------------------------------
| vigenerecipher.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 22, 2019
|
| This program encrypts a message with the vigenere cipher.
|
"""

import math
def encrypt(message, key):
    # YOUR CODE HERE
    

result = encrypt("hello", "abc")
print(result)

