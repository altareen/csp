"""
|-------------------------------------------------------------------------------
| eastersunday.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 10, 2019
|
| This program determines the month and day of Easter.
|
"""

def retrievedate(year):
    # Determine the month and day that Easter occurs, given a particular year.
    # YOUR CODE HERE
    
    
    return (n, p)

result = retrievedate(2001)
print(result)
