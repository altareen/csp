"""
|-------------------------------------------------------------------------------
| requestline.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 19, 2019
|
| This program determines the validity of an HTTP request line.
|
"""

def parse(line):
    # YOUR CODE HERE
    

result = parse("GET /hello.html HTTP/1.1")
print(result)

