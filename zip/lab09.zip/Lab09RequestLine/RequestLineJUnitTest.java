/**
|-------------------------------------------------------------------------------
| RequestLineJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 19, 2019
|
| This is the JUnit test bench for RequestLine.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class RequestLineJUnitTest
{
    @Test
    public void testOne()
    {
        String expected = "/hello.html";
        String actual = RequestLine.parse("GET /hello.html HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        String expected = "/hello.php?";
        String actual = RequestLine.parse("GET /hello.php? HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        String expected = "/hello.php?q=Abigail";
        String actual = RequestLine.parse("GET /hello.php?q=Abigail HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        String expected = "405 Method Not Allowed";
        String actual = RequestLine.parse("POST /pizza.html HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        String expected = "501 Not Implemented";
        String actual = RequestLine.parse("GET burger.php HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        String expected = "400 Bad Request";
        String actual = RequestLine.parse("GET /chicken\"wings.php HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        String expected = "505 HTTP Version Not Supported";
        String actual = RequestLine.parse("GET /chips.html HTTP/1.0");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        String expected = "501 Not Implemented";
        String actual = RequestLine.parse("GET chips.html HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        String expected = "400 Bad Request";
        String actual = RequestLine.parse("GET /gardensalad\".php HTTP/1.1");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        String expected = "505 HTTP Version Not Supported";
        String actual = RequestLine.parse("GET /chips.html HTTP/2.1");
        assertEquals(expected, actual);
    }
}
