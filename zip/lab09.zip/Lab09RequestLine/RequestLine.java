/**
|-------------------------------------------------------------------------------
| RequestLine.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 19, 2019
|
| This program determines the validity of an HTTP request line.
|
*/

public class RequestLine
{
    public static String parse(String line)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String result = parse("GET /hello.html HTTP/1.1");
        System.out.println(result);
    }
}
