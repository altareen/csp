"""
|-------------------------------------------------------------------------------
| genedetection.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 16, 2019
|
| This program determines which genes are present in a DNA sequence.
|
"""

def findgene(dna, stopcodon):
    # YOUR CODE HERE
    

result = findgene("ATATGTAGCTAGCATAATA", "TAA")
print(result)

