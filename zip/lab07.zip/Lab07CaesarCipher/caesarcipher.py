"""
|-------------------------------------------------------------------------------
| caesarcipher.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 06, 2019
|
| This program encrypts a message using the caesar cipher.
|
"""

def encrypt(message, key):
    # YOUR CODE HERE
    

result = encrypt("gardensalad", 10)
print(result)

