"""
|-------------------------------------------------------------------------------
| coinchange.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 11, 2019
|
| This program determines the the minimum number of coins for a particular value.
|
"""

def minimumcoins(cents):
    # YOUR CODE HERE
    

result = minimumcoins(41)
print(result)
