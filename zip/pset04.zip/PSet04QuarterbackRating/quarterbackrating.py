"""
|-------------------------------------------------------------------------------
| quarterbackrating.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 22, 2019
|
| This program determines the passer rating of an NFL quarterback.
|
"""

def calculaterating(attempts, comps, yards, tdowns, picks):
    # YOUR CODE HERE
    
    return rating

result = calculaterating(35, 26, 235, 2, 1)
print(result)

