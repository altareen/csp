"""
|-------------------------------------------------------------------------------
| moviecritic.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 19, 2019
|
| This program determines a user's particular interest in a certain movie.
|
"""

def selectfilm(price, rating):
    # YOUR CODE HERE
    
    return outcome

result = selectfilm(6.50, 3.5)
print(result)

