"""
|-------------------------------------------------------------------------------
| creditcard.py
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 17, 2019
|
| This program determines the validity of a credit card number.
|
|  Valid credit card:   AMEX
|                       MASTERCARD
|                       VISA
|                       VALID
|
|  Invalid credit card: INVALID
|
|  Valid test values:
|  "378282246310005"    AMEX
|  "371449635398431"    AMEX
|  "5555555555554444"   MASTERCARD
|  "5105105105105100"   MASTERCARD
|  "4111111111111111"   VISA
|  "4012888888881881"   VISA
|  "6451962466988955"   VALID
|
|  Invalid test values:
|  "6176292929"         INVALID
|  "1234567890314"      INVALID
|
"""

def validate(digits):
    # YOUR CODE HERE
    

result = validate("378282246310005")
print(result)

